# Custom Lock

An Android app that shows your own lock screen on top of the system one: 7 clock styles, notification styles, a now-playing island, wallpaper with dim/blur, flashlight/camera shortcuts and an optional app PIN.

Inspired by the kind of customisation seen in ColorOS 17 and HyperOS 4. All designs are original. No OPPO or Xiaomi assets are used.

## Get the APK (no Android Studio needed)

1. Create a new repository on GitHub.
2. Upload everything from this folder to it (or `git init`, `git add .`, `git commit`, `git push`).
3. Open the **Actions** tab, then **Build APK**. It runs on every push, or press **Run workflow**.
4. When it finishes, open the run and download **CustomLock-debug-apk** under Artifacts. Unzip it and install `app-debug.apk` on your phone.

If the build fails, open the failed step and copy the error. That is enough to fix it.

## First-time setup on the phone

1. Open **Custom Lock**.
2. Tap **1. Allow display over other apps** and enable it.
3. Tap **2. Allow notification access** and enable Custom Lock (needed for notifications and the music island).
4. Tap **3. Battery settings** and set the app to **Unrestricted**.
5. On Oppo/OnePlus/Realme and Xiaomi/Redmi/Poco also allow **Auto-start**, and on Xiaomi allow **Display pop-up windows while running in the background**. Lock the app in the Recents screen.
6. Turn on **Enable custom lock screen**, then press the power button to test.

## Features

| Area | What you get |
|---|---|
| Clock styles | Glass Colon, Vertical Stack, Rhombus, Magazine, Classic, Text Clock, Analog |
| Clock controls | Size, drag-to-move and X/Y position, weight, colour, multi-colour digits, 12/24 hour, alignment, signature |
| Notifications | Capsule, Stack, List or Off (frosted-style cards) |
| Island | Shows the playing song at the top, tap to play or pause |
| Background | Your own wallpaper, dim, blur (Android 12+) |
| Unlock | Swipe up, or swipe up plus an app PIN |
| Shortcuts | Flashlight and camera |
| Extras | Starts again after reboot |

## Limits you should know

- Android does not let apps replace the real lock screen. This app draws over it, so your normal system PIN, pattern or fingerprint still protects the phone. The app PIN is only an extra layer.
- Some phones stop apps from starting a screen at screen-off. Do the step 4 and 5 settings above. If it still does not show, the phone blocks it.
- Not included: the "depth effect" (clock behind the subject of the photo), real backdrop blur inside notification cards, and the lock-to-home clock transition animation.
- Swiping notifications away or opening them from the lock screen is not implemented yet.

## Project layout

- `app/src/main/java/com/customlock/app/ClockView.kt` all clock designs
- `LockActivity.kt` the lock screen itself
- `LockService.kt` waits for screen-off and launches the lock screen
- `MainActivity.kt` settings and preview
- `NotifListener.kt` reads notifications
- `.github/workflows/build-apk.yml` builds the APK on GitHub

To build locally: open the folder in Android Studio, or run `gradle assembleDebug` with Android SDK 34 installed.
