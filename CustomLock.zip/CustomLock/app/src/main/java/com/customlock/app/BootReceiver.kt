package com.customlock.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.bool(context, K.ENABLED, false)) {
            try {
                context.startForegroundService(Intent(context, LockService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
