package com.customlock.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Draws every clock style. The view fills its parent and is NOT clickable,
 * so touches fall through to whatever is below it.
 * All designs here are original, inspired by the *kind* of layouts that
 * ColorOS / HyperOS offer (glass, vertical, rhombus, magazine, text, analog).
 */
class ClockView(context: Context) : View(context) {

    var cfg: LockConfig = LockConfig.load(context)
        set(value) {
            field = value
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val serifItalic: Typeface = Typeface.create("serif", Typeface.ITALIC)
    private val rainbow = intArrayOf(
        0xFFFF6B6B.toInt(), 0xFFFFD93D.toInt(), 0xFF6BCB77.toInt(),
        0xFF4D96FF.toInt(), 0xFFC77DFF.toInt()
    )

    private var faceCache: Typeface? = null
    private var faceWeight = -1

    private val ones = arrayOf(
        "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE",
        "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN",
        "SEVENTEEN", "EIGHTEEN", "NINETEEN"
    )
    private val tens = arrayOf("", "", "TWENTY", "THIRTY", "FORTY", "FIFTY")

    private val ticker = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 1000L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(ticker)
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    // ---------- helpers ----------

    private fun face(): Typeface {
        if (faceCache == null || faceWeight != cfg.weight) {
            faceWeight = cfg.weight
            faceCache = when (cfg.weight) {
                0 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
                2 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
                else -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
        }
        return faceCache ?: regular
    }

    private fun paintColor(p: Paint, x0: Float, x1: Float, alpha: Int) {
        if (cfg.multicolor) {
            p.shader = LinearGradient(x0, 0f, x1, 0f, rainbow, null, Shader.TileMode.CLAMP)
            p.color = Color.WHITE
        } else {
            p.shader = null
            p.color = cfg.color
        }
        p.alpha = alpha
    }

    private fun leftOf(x: Float, width: Float, align: Paint.Align): Float = when (align) {
        Paint.Align.LEFT -> x
        Paint.Align.CENTER -> x - width / 2f
        else -> x - width
    }

    private fun fitSize(s: String, target: Float): Float {
        fill.typeface = face()
        fill.textSize = 100f
        val w = fill.measureText(s)
        return 100f * target / max(w, 1f)
    }

    private fun solidText(
        c: Canvas, s: String, x: Float, y: Float, size: Float, align: Paint.Align,
        alpha: Int = 255, tf: Typeface? = null, spacing: Float = 0f
    ) {
        fill.typeface = tf ?: face()
        fill.textSize = size
        fill.textAlign = align
        fill.letterSpacing = spacing
        val w = fill.measureText(s)
        val x0 = leftOf(x, w, align)
        paintColor(fill, x0, x0 + w, alpha)
        c.drawText(s, x, y, fill)
        fill.letterSpacing = 0f
    }

    /** Translucent "glass" digits: soft fill, glow and a bright outline. */
    private fun glassText(c: Canvas, s: String, x: Float, y: Float, size: Float, align: Paint.Align) {
        val tf = face()
        fill.typeface = tf
        fill.textSize = size
        fill.textAlign = align
        line.typeface = tf
        line.textSize = size
        line.textAlign = align
        val w = fill.measureText(s)
        val x0 = leftOf(x, w, align)

        paintColor(fill, x0, x0 + w, 105)
        fill.setShadowLayer(size * 0.08f, 0f, 0f, cfg.color)
        c.drawText(s, x, y, fill)
        fill.clearShadowLayer()

        line.strokeWidth = max(2f, size * 0.012f)
        paintColor(line, x0, x0 + w, 235)
        c.drawText(s, x, y, line)
    }

    private fun hh(cal: Calendar, pad: Boolean): String {
        var h = cal.get(Calendar.HOUR_OF_DAY)
        if (!cfg.use24h) {
            h %= 12
            if (h == 0) h = 12
        }
        return if (pad) "%02d".format(h) else h.toString()
    }

    private fun mm(cal: Calendar): String = "%02d".format(cal.get(Calendar.MINUTE))

    private fun dateStr(cal: Calendar, pattern: String): String =
        SimpleDateFormat(pattern, Locale.getDefault()).format(cal.time)

    private fun anchor(w: Float): Pair<Float, Paint.Align> {
        val shift = (cfg.posX - 50) / 100f * w
        return when (cfg.align) {
            0 -> Pair(w * 0.08f + shift, Paint.Align.LEFT)
            2 -> Pair(w * 0.92f + shift, Paint.Align.RIGHT)
            else -> Pair(w / 2f + shift, Paint.Align.CENTER)
        }
    }

    private fun words(n: Int): List<String> = when {
        n < 20 -> listOf(ones[n])
        n % 10 == 0 -> listOf(tens[n / 10])
        else -> listOf(tens[n / 10], ones[n % 10])
    }

    // ---------- drawing ----------

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = cfg.scale / 100f
        val cal = Calendar.getInstance()
        val cx = w / 2f + (cfg.posX - 50) / 100f * w
        val cy = h * cfg.posY / 100f

        when (cfg.style) {
            ClockStyle.GLASS -> drawGlass(c, cal, cx, cy, w * 0.86f * s)
            ClockStyle.VERTICAL -> drawVertical(c, cal, cx, cy, w * 0.50f * s)
            ClockStyle.RHOMBUS -> drawRhombus(c, cal, cx, cy, w * 0.40f * s)
            ClockStyle.MAGAZINE -> drawMagazine(c, cal, w, cy, w * 0.78f * s)
            ClockStyle.CLASSIC -> drawClassic(c, cal, cx, cy, w * 0.62f * s)
            ClockStyle.TEXT -> drawTextClock(c, cal, w, cy, w * 0.15f * s)
            ClockStyle.ANALOG -> drawAnalog(c, cal, cx, cy, w * 0.30f * s)
        }
    }

    private fun drawGlass(c: Canvas, cal: Calendar, cx: Float, cy: Float, target: Float) {
        val t = hh(cal, cfg.use24h) + ":" + mm(cal)
        val size = fitSize(t, target)
        val base = cy + size * 0.36f
        glassText(c, t, cx, base, size, Paint.Align.CENTER)
        solidText(
            c, dateStr(cal, "EEEE, d MMMM"), cx, base + size * 0.30f, size * 0.16f,
            Paint.Align.CENTER, 210, regular
        )
    }

    private fun drawVertical(c: Canvas, cal: Calendar, cx: Float, cy: Float, target: Float) {
        val a = hh(cal, true)
        val b = mm(cal)
        val size = fitSize("88", target)
        val cap = size * 0.72f
        val gap = size * 0.12f
        val top = cy - (2f * cap + gap) / 2f
        solidText(c, a, cx, top + cap, size, Paint.Align.CENTER)
        glassText(c, b, cx, top + 2f * cap + gap, size, Paint.Align.CENTER)
    }

    private fun drawRhombus(c: Canvas, cal: Calendar, cx: Float, cy: Float, r: Float) {
        val path = Path().apply {
            moveTo(cx, cy - r)
            lineTo(cx + r * 0.78f, cy)
            lineTo(cx, cy + r)
            lineTo(cx - r * 0.78f, cy)
            close()
        }
        line.strokeWidth = max(2f, r * 0.02f)
        paintColor(line, cx - r, cx + r, 200)
        c.drawPath(path, line)

        val size = fitSize("88", r * 0.62f)
        val cap = size * 0.72f
        val gap = size * 0.10f
        val top = cy - (2f * cap + gap) / 2f
        solidText(c, hh(cal, true), cx, top + cap, size, Paint.Align.CENTER)
        solidText(c, mm(cal), cx, top + 2f * cap + gap, size, Paint.Align.CENTER, 235)
        solidText(
            c, dateStr(cal, "EEE d MMM").uppercase(), cx, cy + r + size * 0.30f, size * 0.20f,
            Paint.Align.CENTER, 210, regular, 0.15f
        )
    }

    private fun drawMagazine(c: Canvas, cal: Calendar, w: Float, cy: Float, target: Float) {
        val (ax, al) = anchor(w)
        val t = hh(cal, false) + ":" + mm(cal)
        val size = fitSize(t, target)
        solidText(
            c, dateStr(cal, "EEE · MMM d").uppercase(), ax, cy - size * 0.55f, size * 0.14f,
            al, 220, regular, 0.2f
        )
        solidText(c, t, ax, cy + size * 0.30f, size, al)
        if (cfg.signature.isNotBlank()) {
            solidText(
                c, cfg.signature, ax, cy + size * 0.30f + size * 0.30f, size * 0.15f,
                al, 235, serifItalic
            )
        }
    }

    private fun drawClassic(c: Canvas, cal: Calendar, cx: Float, cy: Float, target: Float) {
        val t = hh(cal, cfg.use24h) + ":" + mm(cal)
        val size = fitSize(t, target)
        solidText(
            c, dateStr(cal, "EEE, d MMM"), cx, cy - size * 0.55f, size * 0.22f,
            Paint.Align.CENTER, 220, regular
        )
        solidText(c, t, cx, cy + size * 0.35f, size, Paint.Align.CENTER)
    }

    private fun drawTextClock(c: Canvas, cal: Calendar, w: Float, cy: Float, size: Float) {
        val (ax, al) = anchor(w)
        val lines = ArrayList<String>()
        val hr = hh(cal, false).toInt()
        lines.add(words(hr).joinToString(" "))
        val m = cal.get(Calendar.MINUTE)
        if (m == 0) {
            lines.add("O'CLOCK")
        } else if (m < 10) {
            lines.add("OH")
            lines.add(ones[m])
        } else {
            lines.addAll(words(m))
        }
        val lh = size * 1.0f
        val top = cy - lines.size * lh / 2f
        for ((i, t) in lines.withIndex()) {
            solidText(c, t, ax, top + lh * (i + 0.8f), size, al, if (i == 0) 255 else 190)
        }
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, sw: Float) {
        val a = Math.toRadians(deg.toDouble() - 90.0)
        line.strokeWidth = sw
        c.drawLine(cx, cy, cx + (cos(a) * len).toFloat(), cy + (sin(a) * len).toFloat(), line)
    }

    private fun drawAnalog(c: Canvas, cal: Calendar, cx: Float, cy: Float, r: Float) {
        line.strokeWidth = max(3f, r * 0.025f)
        paintColor(line, cx - r, cx + r, 230)
        c.drawCircle(cx, cy, r, line)
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0 - 90.0)
            val inner = r * (if (i % 3 == 0) 0.80f else 0.88f)
            val outer = r * 0.95f
            c.drawLine(
                cx + (cos(a) * inner).toFloat(), cy + (sin(a) * inner).toFloat(),
                cx + (cos(a) * outer).toFloat(), cy + (sin(a) * outer).toFloat(), line
            )
        }
        val sec = cal.get(Calendar.SECOND)
        val min = cal.get(Calendar.MINUTE) + sec / 60f
        val hour = (cal.get(Calendar.HOUR) % 12) + min / 60f

        paintColor(line, cx - r, cx + r, 255)
        hand(c, cx, cy, hour / 12f * 360f, r * 0.50f, max(4f, r * 0.045f))
        hand(c, cx, cy, min / 60f * 360f, r * 0.78f, max(3f, r * 0.03f))

        line.shader = null
        line.color = 0xFFFF5A5F.toInt()
        hand(c, cx, cy, sec / 60f * 360f, r * 0.86f, max(2f, r * 0.012f))

        paintColor(fill, cx - r, cx + r, 255)
        c.drawCircle(cx, cy, max(4f, r * 0.04f), fill)

        solidText(
            c, dateStr(cal, "EEE, d MMM"), cx, cy + r + r * 0.35f, r * 0.20f,
            Paint.Align.CENTER, 210, regular
        )
    }
}
