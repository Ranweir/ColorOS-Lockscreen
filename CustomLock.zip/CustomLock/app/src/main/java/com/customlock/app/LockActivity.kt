package com.customlock.app

import android.app.Activity
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var cfg: LockConfig
    private lateinit var root: FrameLayout
    private var notifBox: LinearLayout? = null
    private var island: TextView? = null
    private var pinOverlay: View? = null
    private var mediaCtl: MediaController? = null
    private var torchOn = false
    private var unlocking = false
    private val handler = Handler(Looper.getMainLooper())

    private val islandTick = object : Runnable {
        override fun run() {
            renderIsland()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        build()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        build()
        renderNotifs()
        renderIsland()
    }

    override fun onResume() {
        super.onResume()
        unlocking = false
        hideBars()
        NotifListener.onChange = { renderNotifs() }
        renderNotifs()
        handler.removeCallbacks(islandTick)
        handler.post(islandTick)
    }

    override fun onPause() {
        NotifListener.onChange = null
        handler.removeCallbacks(islandTick)
        super.onPause()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (pinOverlay != null) dismissPin()
        // Otherwise swallow back so the lock screen cannot be skipped.
    }

    // ---------- UI ----------

    private fun build() {
        cfg = LockConfig.load(this)
        unlocking = false
        pinOverlay = null
        root = FrameLayout(this)

        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val uri = Prefs.str(this, K.WALLPAPER, "")
        val bmp: Bitmap? = if (uri.isNotEmpty()) Util.loadBitmap(this, uri, 1080) else null
        if (bmp != null) bg.setImageBitmap(bmp) else bg.setImageDrawable(Util.defaultBackground())
        if (Build.VERSION.SDK_INT >= 31 && cfg.blur > 0) {
            val r = cfg.blur.toFloat()
            bg.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            bg.scaleX = 1.12f
            bg.scaleY = 1.12f
        }
        root.addView(bg, FrameLayout.LayoutParams(MATCH, MATCH))

        val dim = View(this)
        dim.setBackgroundColor(Color.argb(cfg.dim * 255 / 100, 0, 0, 0))
        root.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))

        val clock = ClockView(this)
        clock.cfg = cfg
        root.addView(clock, FrameLayout.LayoutParams(MATCH, MATCH))

        // Lockscreen island (now playing)
        if (cfg.island) {
            val isl = TextView(this)
            isl.textSize = 13f
            isl.setTextColor(Color.WHITE)
            isl.maxLines = 1
            isl.maxWidth = dp(280)
            isl.ellipsize = TextUtils.TruncateAt.END
            isl.setPadding(dp(16), dp(8), dp(16), dp(8))
            isl.visibility = View.GONE
            val shape = GradientDrawable()
            shape.cornerRadius = dpf(24f)
            shape.setColor(0xE6000000.toInt())
            isl.background = shape
            isl.setOnClickListener { toggleMedia() }
            val ip = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            ip.topMargin = dp(40)
            root.addView(isl, ip)
            island = isl
        } else {
            island = null
        }

        // Notifications
        val nb = LinearLayout(this)
        nb.orientation = LinearLayout.VERTICAL
        val np = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        np.setMargins(dp(16), 0, dp(16), dp(140))
        root.addView(nb, np)
        notifBox = nb

        // Hint
        val hint = TextView(this)
        hint.text = if (cfg.unlock == UnlockMode.PIN) "Swipe up, then enter PIN" else "Swipe up to unlock"
        hint.textSize = 13f
        hint.setTextColor(0xAAFFFFFF.toInt())
        hint.gravity = Gravity.CENTER
        val hp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        hp.bottomMargin = dp(32)
        root.addView(hint, hp)

        // Shortcuts
        if (cfg.shortcuts) {
            val torch = roundButton("🔦") { toggleTorch() }
            val tp = FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.START)
            tp.setMargins(dp(32), 0, 0, dp(56))
            root.addView(torch, tp)

            val cam = roundButton("📷") { openCamera() }
            val cp = FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.END)
            cp.setMargins(0, 0, dp(32), dp(56))
            root.addView(cam, cp)
        }

        // Swipe up to unlock
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (velocityY < -900f) {
                    onSwipeUp()
                    return true
                }
                return false
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (e1 != null && e1.y - e2.y > dp(160)) {
                    onSwipeUp()
                    return true
                }
                return false
            }
        })
        root.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }

        setContentView(root)
        hideBars()
    }

    private fun roundButton(label: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 22f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        val shape = GradientDrawable()
        shape.shape = GradientDrawable.OVAL
        shape.setColor(0x44FFFFFF)
        shape.setStroke(dp(1), 0x66FFFFFF)
        tv.background = shape
        tv.setOnClickListener { onClick() }
        return tv
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val ic = window.insetsController
            if (ic != null) {
                ic.hide(WindowInsets.Type.systemBars())
                ic.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // ---------- notifications ----------

    private fun card(n: NotifItem): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(12), dp(16), dp(12))
        val shape = GradientDrawable()
        shape.cornerRadius = dpf(22f)
        shape.setColor(0xB0202030.toInt())
        shape.setStroke(dp(1), 0x44FFFFFF)
        box.background = shape

        val app = TextView(this)
        app.text = n.app.uppercase()
        app.textSize = 11f
        app.setTextColor(0xAAFFFFFF.toInt())
        box.addView(app)

        val title = TextView(this)
        title.text = n.title
        title.textSize = 15f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        box.addView(title)

        if (n.text.isNotEmpty()) {
            val body = TextView(this)
            body.text = n.text
            body.textSize = 13f
            body.setTextColor(0xDDFFFFFF.toInt())
            body.maxLines = 2
            body.ellipsize = TextUtils.TruncateAt.END
            box.addView(body)
        }
        return box
    }

    private fun pill(text: String): View {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(20), dp(12), dp(20), dp(12))
        val shape = GradientDrawable()
        shape.cornerRadius = dpf(40f)
        shape.setColor(0xB0202030.toInt())
        shape.setStroke(dp(1), 0x44FFFFFF)
        tv.background = shape
        return tv
    }

    private fun renderNotifs() {
        val box = notifBox ?: return
        box.removeAllViews()
        val list = NotifListener.items
        if (list.isEmpty() || cfg.notifStyle == NotifStyle.OFF) return

        when (cfg.notifStyle) {
            NotifStyle.CAPSULE -> {
                val first = list[0]
                val head = if (list.size == 1) "1 notification" else list.size.toString() + " notifications"
                val tail = if (first.title.isNotEmpty()) " · " + first.title else ""
                box.addView(pill("🔔 " + head + tail))
            }
            NotifStyle.STACK -> {
                val shown = list.take(3)
                val stack = FrameLayout(this)
                stack.clipChildren = false
                stack.setPadding(0, 0, 0, dp(22))
                for (i in shown.indices.reversed()) {
                    val v = card(shown[i])
                    v.scaleX = 1f - 0.05f * i
                    v.translationY = dp(10) * i.toFloat()
                    v.alpha = 1f - 0.20f * i
                    stack.addView(v, FrameLayout.LayoutParams(MATCH, WRAP))
                }
                box.addView(stack, LinearLayout.LayoutParams(MATCH, WRAP))
            }
            NotifStyle.LIST -> {
                for (n in list.take(5)) {
                    val lp = LinearLayout.LayoutParams(MATCH, WRAP)
                    lp.topMargin = dp(8)
                    box.addView(card(n), lp)
                }
            }
            NotifStyle.OFF -> {
            }
        }
    }

    // ---------- island / media ----------

    private fun findController(): MediaController? {
        return try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val l = msm.getActiveSessions(ComponentName(this, NotifListener::class.java))
            l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: l.firstOrNull { it.metadata != null }
        } catch (e: Exception) {
            null
        }
    }

    private fun renderIsland() {
        val isl = island ?: return
        val ctl = findController()
        mediaCtl = ctl
        val md = ctl?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (ctl == null || title.isNullOrEmpty()) {
            isl.visibility = View.GONE
            return
        }
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        val playing = ctl.playbackState?.state == PlaybackState.STATE_PLAYING
        val sym = if (playing) "▶  " else "⏸  "
        isl.text = sym + title + (if (artist.isNullOrEmpty()) "" else " · $artist")
        isl.visibility = View.VISIBLE
    }

    private fun toggleMedia() {
        val ctl = mediaCtl ?: return
        if (ctl.playbackState?.state == PlaybackState.STATE_PLAYING) {
            ctl.transportControls.pause()
        } else {
            ctl.transportControls.play()
        }
        handler.postDelayed({ renderIsland() }, 300L)
    }

    // ---------- shortcuts ----------

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
        }
    }

    private fun openCamera() {
        try {
            startActivity(
                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e2: Exception) {
            }
        }
    }

    // ---------- unlock ----------

    private fun onSwipeUp() {
        if (unlocking || pinOverlay != null) return
        val hasPin = Prefs.str(this, K.PIN_HASH, "").isNotEmpty()
        if (cfg.unlock == UnlockMode.PIN && hasPin) showPin() else unlock()
    }

    private fun unlock() {
        if (unlocking) return
        unlocking = true
        val km = getSystemService(KeyguardManager::class.java)
        if (km != null && km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    finishAndRemoveTask()
                }

                override fun onDismissCancelled() {
                    unlocking = false
                }

                override fun onDismissError() {
                    finishAndRemoveTask()
                }
            })
        } else {
            finishAndRemoveTask()
        }
    }

    private fun dismissPin() {
        pinOverlay?.let { root.removeView(it) }
        pinOverlay = null
    }

    private fun showPin() {
        if (pinOverlay != null) return
        val stored = Prefs.str(this, K.PIN_HASH, "")
        val sb = StringBuilder()

        val overlay = LinearLayout(this)
        overlay.orientation = LinearLayout.VERTICAL
        overlay.gravity = Gravity.CENTER
        overlay.setBackgroundColor(0xCC000000.toInt())
        overlay.isClickable = true

        val dots = TextView(this)
        dots.textSize = 28f
        dots.setTextColor(Color.WHITE)
        dots.gravity = Gravity.CENTER
        dots.setPadding(0, 0, 0, dp(16))
        dots.text = " "
        overlay.addView(dots)

        fun refresh() {
            dots.text = if (sb.isEmpty()) " " else "●".repeat(sb.length)
        }

        fun check() {
            if (Util.sha256(sb.toString()) == stored) {
                dismissPin()
                unlock()
            } else {
                sb.setLength(0)
                refresh()
                dots.animate().translationX(24f).setDuration(70L).withEndAction {
                    dots.animate().translationX(0f).setDuration(70L)
                }
            }
        }

        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✓")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (col in 0 until 3) {
                val k = keys[r * 3 + col]
                val shape = GradientDrawable()
                shape.shape = GradientDrawable.OVAL
                shape.setColor(0x33FFFFFF)
                val b = TextView(this)
                b.text = k
                b.textSize = 26f
                b.gravity = Gravity.CENTER
                b.setTextColor(Color.WHITE)
                b.background = shape
                b.setOnClickListener {
                    if (k == "⌫") {
                        if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
                    } else if (k == "✓") {
                        check()
                    } else if (sb.length < 8) {
                        sb.append(k)
                    }
                    refresh()
                }
                val lp = LinearLayout.LayoutParams(dp(72), dp(72))
                lp.setMargins(dp(10), dp(8), dp(10), dp(8))
                row.addView(b, lp)
            }
            overlay.addView(row)
        }

        val cancel = TextView(this)
        cancel.text = "Cancel"
        cancel.textSize = 16f
        cancel.setTextColor(0xCCFFFFFF.toInt())
        cancel.setPadding(dp(24), dp(20), dp(24), dp(20))
        cancel.setOnClickListener { dismissPin() }
        overlay.addView(cancel)

        root.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))
        pinOverlay = overlay
    }
}
