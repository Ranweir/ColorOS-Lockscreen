package com.customlock.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var content: LinearLayout
    private lateinit var preview: ClockView
    private lateinit var previewBox: FrameLayout
    private lateinit var previewBg: ImageView
    private lateinit var status: TextView
    private lateinit var enableSwitch: Switch

    private val palette = intArrayOf(
        Color.WHITE, 0xFFFFD93D.toInt(), 0xFFFF6B6B.toInt(), 0xFF6BCB77.toInt(),
        0xFF4D96FF.toInt(), 0xFFC77DFF.toInt(), 0xFFFF9F45.toInt(), Color.BLACK
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(32), dp(16), dp(48))
        scroll.addView(content)
        setContentView(scroll)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------- small UI helpers ----------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun header(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 18f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(0, dp(24), 0, dp(6))
        content.addView(tv)
    }

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 14f
        tv.setPadding(0, dp(10), 0, 0)
        return tv
    }

    private fun button(t: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        content.addView(b)
    }

    private fun switchRow(t: String, key: String, def: Boolean) {
        val sw = Switch(this)
        sw.text = t
        sw.isChecked = Prefs.bool(this, key, def)
        sw.setPadding(0, dp(8), 0, dp(8))
        sw.setOnCheckedChangeListener { _, v ->
            Prefs.put(this, key, v)
            refreshPreview()
        }
        content.addView(sw)
    }

    private fun seekRow(t: String, key: String, lo: Int, hi: Int, def: Int, unit: String) {
        val tv = label(t + ": " + Prefs.int(this, key, def) + unit)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = Prefs.int(this, key, def) - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                tv.text = t + ": " + v + unit
                Prefs.put(this@MainActivity, key, v)
                refreshPreview()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(tv)
        content.addView(sb)
    }

    private fun spinnerRow(t: String, items: List<String>, key: String, def: Int) {
        content.addView(label(t))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(Prefs.int(this, key, def))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Prefs.put(this@MainActivity, key, pos)
                refreshPreview()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        content.addView(sp)
    }

    private fun refreshPreview() {
        if (::preview.isInitialized) preview.cfg = LockConfig.load(this)
    }

    private fun loadPreviewWallpaper() {
        val u = Prefs.str(this, K.WALLPAPER, "")
        val bmp = if (u.isNotEmpty()) Util.loadBitmap(this, u, 720) else null
        if (bmp != null) previewBg.setImageBitmap(bmp) else previewBg.setImageDrawable(Util.defaultBackground())
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val notif = listeners != null && listeners.contains(packageName)
        status.text = "Overlay permission: " + (if (overlay) "granted" else "needed") +
            "\nNotification access: " + (if (notif) "granted" else "needed (for notifications and music)")
    }

    // ---------- screen ----------

    private fun buildUi() {
        val title = TextView(this)
        title.text = "Custom Lock"
        title.textSize = 28f
        title.typeface = Typeface.DEFAULT_BOLD
        content.addView(title)

        status = TextView(this)
        status.textSize = 13f
        status.setPadding(0, dp(8), 0, dp(8))
        content.addView(status)

        enableSwitch = Switch(this)
        enableSwitch.text = "Enable custom lock screen"
        enableSwitch.textSize = 16f
        enableSwitch.isChecked = Prefs.bool(this, K.ENABLED, false)
        enableSwitch.setOnCheckedChangeListener { _, on ->
            if (on && !Settings.canDrawOverlays(this)) {
                enableSwitch.isChecked = false
                toast("Grant the overlay permission first")
            } else {
                Prefs.put(this, K.ENABLED, on)
                val i = Intent(this, LockService::class.java)
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    }
                    startForegroundService(i)
                } else {
                    stopService(i)
                }
            }
        }
        content.addView(enableSwitch)

        button("1. Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. Battery settings (set to Unrestricted)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        button("Test lock screen now") {
            startActivity(Intent(this, LockActivity::class.java))
        }

        // ----- preview -----
        header("Preview (drag to move the clock)")
        previewBox = FrameLayout(this)
        val boxShape = GradientDrawable()
        boxShape.cornerRadius = dpf(24f)
        boxShape.setColor(Color.BLACK)
        previewBox.background = boxShape
        previewBox.clipToOutline = true
        previewBg = ImageView(this)
        previewBg.scaleType = ImageView.ScaleType.CENTER_CROP
        previewBox.addView(previewBg, FrameLayout.LayoutParams(MATCH, MATCH))
        preview = ClockView(this)
        previewBox.addView(preview, FrameLayout.LayoutParams(MATCH, MATCH))
        previewBox.setOnTouchListener { v, ev ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            if (ev.action == MotionEvent.ACTION_DOWN || ev.action == MotionEvent.ACTION_MOVE) {
                val x = (ev.x / v.width * 100f).toInt().coerceIn(0, 100)
                val y = (ev.y / v.height * 100f).toInt().coerceIn(0, 100)
                Prefs.put(this, K.POSX, x)
                Prefs.put(this, K.POSY, y)
                refreshPreview()
            }
            true
        }
        val pp = LinearLayout.LayoutParams(dp(240), dp(420))
        pp.gravity = Gravity.CENTER_HORIZONTAL
        content.addView(previewBox, pp)
        loadPreviewWallpaper()

        // ----- clock -----
        header("Clock")
        spinnerRow("Style", ClockStyle.values().map { it.label }, K.STYLE, 0)
        seekRow("Size", K.SCALE, 50, 200, 100, "%")
        seekRow("Position X", K.POSX, 0, 100, 50, "%")
        seekRow("Position Y", K.POSY, 0, 100, 30, "%")
        spinnerRow("Weight", listOf("Thin", "Regular", "Bold"), K.WEIGHT, 1)
        spinnerRow("Alignment (Magazine and Text styles)", listOf("Left", "Center", "Right"), K.ALIGN, 1)

        content.addView(label("Colour"))
        val swatches = LinearLayout(this)
        swatches.orientation = LinearLayout.HORIZONTAL
        for (col in palette) {
            val dot = View(this)
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.OVAL
            shape.setColor(col)
            shape.setStroke(dp(1), 0x88888888.toInt())
            dot.background = shape
            dot.setOnClickListener {
                Prefs.put(this, K.COLOR, col)
                Prefs.put(this, K.MULTI, false)
                refreshPreview()
            }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(0, dp(6), dp(10), dp(6))
            swatches.addView(dot, lp)
        }
        content.addView(swatches)
        switchRow("Multi-colour digits", K.MULTI, false)
        switchRow("24-hour time", K.H24, false)

        content.addView(label("Signature (Magazine style)"))
        val sig = EditText(this)
        sig.setText(Prefs.str(this, K.SIG, ""))
        sig.hint = "Your text"
        sig.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.put(this@MainActivity, K.SIG, s?.toString() ?: "")
                refreshPreview()
            }
        })
        content.addView(sig)

        // ----- notifications -----
        header("Notifications")
        spinnerRow("Style", NotifStyle.values().map { it.label }, K.NOTIF, 1)

        // ----- background -----
        header("Background")
        button("Choose wallpaper") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            startActivityForResult(i, 42)
        }
        button("Use default background") {
            Prefs.put(this, K.WALLPAPER, "")
            loadPreviewWallpaper()
        }
        seekRow("Dim", K.DIM, 0, 80, 25, "%")
        seekRow("Blur (Android 12+)", K.BLUR, 0, 40, 0, "")

        // ----- behaviour -----
        header("Lock behaviour")
        spinnerRow("Unlock method", UnlockMode.values().map { it.label }, K.UNLOCK, 0)
        button("Set app PIN") { pinDialog() }
        switchRow("Lockscreen island (now playing)", K.ISLAND, true)
        switchRow("Flashlight and camera shortcuts", K.SHORTCUTS, true)

        val note = TextView(this)
        note.text = "This app draws over the system lock screen. If your phone has a PIN, pattern " +
            "or fingerprint, Android still asks for it after you swipe up. Keep it set."
        note.textSize = 12f
        note.setPadding(0, dp(20), 0, 0)
        content.addView(note)
    }

    private fun pinDialog() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.hint = "4 to 8 digits"
        AlertDialog.Builder(this)
            .setTitle("Set app PIN")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val p = et.text.toString()
                if (p.length in 4..8) {
                    Prefs.put(this, K.PIN_HASH, Util.sha256(p))
                    toast("PIN saved. Choose 'Swipe up + app PIN' as unlock method.")
                } else {
                    toast("Use 4 to 8 digits")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val u = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Prefs.put(this, K.WALLPAPER, u.toString())
            loadPreviewWallpaper()
        }
    }
}
