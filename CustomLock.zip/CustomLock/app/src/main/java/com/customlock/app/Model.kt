package com.customlock.app

import android.content.Context
import android.graphics.Color

enum class ClockStyle(val label: String) {
    GLASS("Glass Colon"),
    VERTICAL("Vertical Stack"),
    RHOMBUS("Rhombus"),
    MAGAZINE("Magazine"),
    CLASSIC("Classic"),
    TEXT("Text Clock"),
    ANALOG("Analog")
}

enum class NotifStyle(val label: String) {
    CAPSULE("Capsule"),
    STACK("Stack"),
    LIST("List"),
    OFF("Off")
}

enum class UnlockMode(val label: String) {
    SWIPE("Swipe up"),
    PIN("Swipe up + app PIN")
}

object K {
    const val ENABLED = "enabled"
    const val STYLE = "style"
    const val SCALE = "scale"
    const val WEIGHT = "weight"
    const val COLOR = "color"
    const val MULTI = "multi"
    const val H24 = "h24"
    const val POSX = "posx"
    const val POSY = "posy"
    const val ALIGN = "align"
    const val SIG = "sig"
    const val NOTIF = "notif"
    const val DIM = "dim"
    const val BLUR = "blur"
    const val UNLOCK = "unlock"
    const val ISLAND = "island"
    const val SHORTCUTS = "shortcuts"
    const val WALLPAPER = "wallpaper"
    const val PIN_HASH = "pin_hash"
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("customlock", Context.MODE_PRIVATE)

    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d

    fun put(c: Context, k: String, v: Int) {
        sp(c).edit().putInt(k, v).apply()
    }

    fun put(c: Context, k: String, v: Boolean) {
        sp(c).edit().putBoolean(k, v).apply()
    }

    fun put(c: Context, k: String, v: String) {
        sp(c).edit().putString(k, v).apply()
    }
}

data class LockConfig(
    val style: ClockStyle,
    val scale: Int,
    val weight: Int,
    val color: Int,
    val multicolor: Boolean,
    val use24h: Boolean,
    val posX: Int,
    val posY: Int,
    val align: Int,
    val signature: String,
    val notifStyle: NotifStyle,
    val dim: Int,
    val blur: Int,
    val unlock: UnlockMode,
    val island: Boolean,
    val shortcuts: Boolean
) {
    companion object {
        fun load(c: Context): LockConfig = LockConfig(
            style = ClockStyle.values().getOrElse(Prefs.int(c, K.STYLE, 0)) { ClockStyle.GLASS },
            scale = Prefs.int(c, K.SCALE, 100),
            weight = Prefs.int(c, K.WEIGHT, 1),
            color = Prefs.int(c, K.COLOR, Color.WHITE),
            multicolor = Prefs.bool(c, K.MULTI, false),
            use24h = Prefs.bool(c, K.H24, false),
            posX = Prefs.int(c, K.POSX, 50),
            posY = Prefs.int(c, K.POSY, 30),
            align = Prefs.int(c, K.ALIGN, 1),
            signature = Prefs.str(c, K.SIG, ""),
            notifStyle = NotifStyle.values().getOrElse(Prefs.int(c, K.NOTIF, 1)) { NotifStyle.STACK },
            dim = Prefs.int(c, K.DIM, 25),
            blur = Prefs.int(c, K.BLUR, 0),
            unlock = UnlockMode.values().getOrElse(Prefs.int(c, K.UNLOCK, 0)) { UnlockMode.SWIPE },
            island = Prefs.bool(c, K.ISLAND, true),
            shortcuts = Prefs.bool(c, K.SHORTCUTS, true)
        )
    }
}
