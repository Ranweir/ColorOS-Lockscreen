package com.customlock.app

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NotifItem(
    val key: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long
)

class NotifListener : NotificationListenerService() {

    companion object {
        @Volatile
        var items: List<NotifItem> = emptyList()

        @Volatile
        var onChange: (() -> Unit)? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        refresh()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refresh()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refresh()
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun refresh() {
        val raw: Array<StatusBarNotification> = try {
            val a: Array<StatusBarNotification>? = activeNotifications
            a ?: emptyArray<StatusBarNotification>()
        } catch (e: Exception) {
            emptyArray<StatusBarNotification>()
        }
        val me = applicationContext.packageName
        items = raw
            .filter {
                !it.isOngoing &&
                    (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                    it.packageName != me
            }
            .sortedByDescending { it.postTime }
            .map { n ->
                val ex = n.notification.extras
                NotifItem(
                    n.key,
                    appLabel(n.packageName),
                    ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "",
                    ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "",
                    n.postTime
                )
            }
        Handler(Looper.getMainLooper()).post { onChange?.invoke() }
    }
}
