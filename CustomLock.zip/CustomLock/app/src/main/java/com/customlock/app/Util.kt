package com.customlock.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import java.security.MessageDigest

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

object Util {
    fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(("customlock:$s").toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun defaultBackground(): Drawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xFF1B2A49.toInt(), 0xFF6A3E7C.toInt(), 0xFFE08E6D.toInt())
    )

    fun loadBitmap(c: Context, uriStr: String, targetW: Int): Bitmap? {
        return try {
            val uri = Uri.parse(uriStr)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= targetW) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            null
        }
    }
}
